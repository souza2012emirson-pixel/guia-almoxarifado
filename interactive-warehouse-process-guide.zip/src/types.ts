/**
 * Modelo de dados dos processos do guia.
 *
 * Cada fluxo é uma lista de passos (`steps`). Cada passo tem um `id` único e
 * aponta para outros passos pelos campos `next`, `target` (opções) e `onNo`.
 * Para adicionar ou alterar um fluxo, edite apenas os arquivos em
 * `src/data/processes/` — este arquivo define apenas o formato.
 */

/** Tom visual de uma nota/alerta. */
export type NoteTone = "info" | "warning" | "danger" | "success" | "validate";

export interface Note {
  tone: NoteTone;
  /** Título curto exibido em negrito. */
  title?: string;
  /** Texto do alerta. Para `validate`, se omitido, usa a mensagem padrão de validação. */
  text?: string;
}

/** Opção de resposta: leva o usuário a outro passo. */
export interface Option {
  label: string;
  /** id do passo de destino. */
  target: string;
  /** Define a cor do botão. `success` = verde, `warning` = amarelo, `danger` = vermelho. */
  tone?: "primary" | "success" | "warning" | "danger" | "secondary";
}

interface StepBase {
  id: string;
  /** id de uma etapa de `flow.stages` (usado no indicador de progresso). */
  stage: string;
  title: string;
  /** Alertas exibidos em destaque no topo do passo. */
  notes?: Note[];
}

/** Instrução: o usuário executa algo e confirma com "Sim, concluído". */
export interface InstructionStep extends StepBase {
  kind: "instruction";
  body: string[];
  /** Caminho de menus, exibido como trilha visual (ex.: Atualizações → Movimentações). */
  menuPath?: string[];
  next: string;
  nextLabel?: string;
}

/** Pergunta de escolha única: cada opção leva a um destino diferente. */
export interface QuestionStep extends StepBase {
  kind: "question";
  question: string;
  body?: string[];
  options: Option[];
}

/**
 * Conjunto de verificações obrigatórias. Cada pergunta respondida com "Não"
 * leva ao destino `onNo`. O avanço só é liberado quando todas forem "Sim".
 */
export interface MultiQuestionStep extends StepBase {
  kind: "multi-question";
  body?: string[];
  questions: {
    id: string;
    text: string;
    hint?: string;
    onNo: string;
  }[];
  next: string;
  nextLabel?: string;
}

/**
 * Exceção. Sempre explica: o que foi identificado, o que verificar,
 * a ação permitida e quando interromper. Sem `options` = parada (fluxo interrompido).
 */
export interface ExceptionStep extends StepBase {
  kind: "exception";
  identified: string;
  verify: string[];
  allowed: string[];
  stopWhen: string;
  options?: Option[];
}

/** Checklist final: só libera o avanço quando todos os itens forem marcados. */
export interface ChecklistStep extends StepBase {
  kind: "checklist";
  body?: string[];
  items: string[];
  next: string;
  nextLabel?: string;
}

/** Encerramento do processo. */
export interface EndStep extends StepBase {
  kind: "end";
  body: string[];
}

export type Step =
  | InstructionStep
  | QuestionStep
  | MultiQuestionStep
  | ExceptionStep
  | ChecklistStep
  | EndStep;

export interface Stage {
  id: string;
  label: string;
}

export interface FlowDefinition {
  id: string;
  title: string;
  /** Texto de origem/validação exibido no rodapé do fluxo. */
  source: string;
  stages: Stage[];
  /** id do primeiro passo. */
  start: string;
  steps: Step[];
}

export type ProcessStatus = "disponivel" | "em-desenvolvimento";

export interface ProcessDefinition {
  id: string;
  title: string;
  category: string;
  description: string;
  /** Palavras-chave usadas na busca da página inicial. */
  keywords: string[];
  status: ProcessStatus;
  /** Obrigatório quando `status` é `disponivel`. */
  flow?: FlowDefinition;
}
