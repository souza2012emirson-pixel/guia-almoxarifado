import type { Stage } from "../types";
import type { TrailItem } from "../engine/flowEngine";
import { cn } from "../utils/cn";
import { Icon } from "./icons";
import { Button } from "./ui";

/* ───────────── Indicador de progresso ───────────── */

export function ProgressPanel({
  stages,
  currentIndex,
  stepsCount,
}: {
  stages: Stage[];
  currentIndex: number;
  stepsCount: number;
}) {
  const current = stages[currentIndex];
  const percent = Math.round((currentIndex / Math.max(stages.length - 1, 1)) * 100);

  return (
    <section aria-label="Progresso do processo" className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-4 sm:p-5">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <p className="text-xs uppercase tracking-wide text-zinc-500">Progresso</p>
          <p className="text-sm text-zinc-200">
            <span className="font-semibold text-white">
              Etapa {currentIndex + 1} de {stages.length}
            </span>
            {current && <span className="text-zinc-400"> · {current.label}</span>}
          </p>
        </div>
        <p className="text-sm text-zinc-400">
          {percent}% · {stepsCount} {stepsCount === 1 ? "passo registrado" : "passos registrados"}
        </p>
      </div>

      <div className="mt-3 h-2 overflow-hidden rounded-full bg-zinc-800">
        <div
          className="h-full rounded-full bg-violet-500 transition-all duration-500"
          style={{ width: `${percent}%` }}
          role="presentation"
        />
      </div>

      <ol className="mt-4 grid gap-1.5" style={{ gridTemplateColumns: `repeat(${stages.length}, minmax(0, 1fr))` }}>
        {stages.map((stage, index) => {
          const status = index < currentIndex ? "done" : index === currentIndex ? "current" : "pending";
          return (
            <li key={stage.id} className="flex min-w-0 flex-col items-center gap-1.5 text-center">
              <span
                className={cn(
                  "flex h-8 w-8 items-center justify-center rounded-full border text-xs font-semibold transition",
                  status === "done" && "border-emerald-500 bg-emerald-500 text-zinc-950",
                  status === "current" && "border-violet-400 bg-violet-600 text-white ring-4 ring-violet-500/20",
                  status === "pending" && "border-zinc-700 bg-zinc-800 text-zinc-500",
                )}
              >
                {status === "done" ? <Icon name="check" className="h-4 w-4" /> : stage.id}
              </span>
              <span
                className={cn(
                  "hidden w-full truncate text-[11px] leading-tight md:block",
                  status === "current" ? "text-violet-200" : "text-zinc-500",
                )}
              >
                {stage.label}
              </span>
              <span className="sr-only">
                {stage.label}: {status === "done" ? "concluída" : status === "current" ? "atual" : "pendente"}
              </span>
            </li>
          );
        })}
      </ol>
    </section>
  );
}

/* ───────────── Caminho percorrido (trilha) ───────────── */

export function TrailBar({
  trail,
  currentIndex,
  onJump,
}: {
  trail: TrailItem[];
  currentIndex: number;
  onJump: (index: number) => void;
}) {
  return (
    <nav aria-label="Caminho percorrido" className="rounded-2xl border border-zinc-800 bg-zinc-900/60 p-4">
      <p className="mb-3 text-xs uppercase tracking-wide text-zinc-500">Caminho percorrido</p>
      <ol className="flex gap-2 overflow-x-auto pb-1">
        {trail.map((item, index) => {
          const isCurrent = index === currentIndex;
          return (
            <li key={`${item.id}-${index}`} className="shrink-0">
              <button
                type="button"
                disabled={isCurrent}
                onClick={() => onJump(index)}
                aria-current={isCurrent ? "step" : undefined}
                title={isCurrent ? "Etapa atual" : `Revisar: ${item.title}`}
                className={cn(
                  "flex max-w-[240px] items-center gap-2 rounded-lg border px-3 py-1.5 text-left text-xs transition",
                  "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-400",
                  isCurrent
                    ? "border-violet-500 bg-violet-600/20 text-violet-100"
                    : "border-zinc-700 bg-zinc-800/60 text-zinc-300 hover:border-zinc-500 hover:text-white",
                )}
              >
                <span
                  className={cn(
                    "flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[10px] font-semibold",
                    isCurrent ? "bg-violet-500 text-white" : "bg-zinc-700 text-zinc-200",
                  )}
                >
                  {index + 1}
                </span>
                <span className="truncate">{item.title}</span>
                {item.answer && (
                  <span className="hidden shrink-0 rounded bg-zinc-950/70 px-1.5 py-0.5 text-[10px] text-zinc-400 md:inline">
                    {item.answer}
                  </span>
                )}
              </button>
            </li>
          );
        })}
      </ol>
      <p className="mt-2 text-xs text-zinc-500">
        Clique em uma etapa anterior para revisá-la. As respostas ficam registradas até reiniciar o processo.
      </p>
    </nav>
  );
}

/* ───────────── Painel lateral de alertas e orientações ───────────── */

const stopTriggers = [
  "Produto não localizado mesmo após revisar código e filtro.",
  "Indicador vermelho sem esclarecimento da entrada ou da situação do endereçamento.",
  "Produto em armazém diferente do esperado (encaminhar ao responsável pela transferência).",
  "Divergência entre a quantidade física e a quantidade do sistema.",
  "Endereço cujo local físico não foi confirmado.",
  "Aviso do sistema ao informar o endereço que não foi resolvido.",
  "Qualquer dúvida que não esteja descrita no procedimento.",
];

export function AlertsPanel() {
  return (
    <aside
      aria-label="Painel de alertas e orientações"
      className="space-y-4 lg:sticky lg:top-24 lg:self-start"
    >
      <div className="rounded-2xl border border-red-500/30 bg-red-500/5 p-5">
        <h3 className="flex items-center gap-2 text-sm font-semibold text-white">
          <Icon name="octagon" className="h-4 w-4 text-red-300" />
          Interrompa e consulte o responsável quando
        </h3>
        <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-zinc-300 marker:text-red-400">
          {stopTriggers.map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
      </div>

      <div className="rounded-2xl border border-violet-500/30 bg-violet-500/5 p-5">
        <h3 className="flex items-center gap-2 text-sm font-semibold text-white">
          <Icon name="shield" className="h-4 w-4 text-violet-300" />
          Regras do guia
        </h3>
        <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-zinc-300 marker:text-violet-400">
          <li>Este guia não substitui a conferência no TOTVS Protheus nem as regras internas autorizadas.</li>
          <li>Não está integrado ao TOTVS e não confirma que uma operação foi salva.</li>
          <li>Não presuma autorização para transferências, ajustes de saldo ou cadastros.</li>
          <li>Não invente códigos de box nem contorne avisos do sistema.</li>
        </ul>
      </div>
    </aside>
  );
}

/* ───────────── Painel de ajuda ───────────── */

export function HelpPanel({
  stageLabel,
  stepTitle,
  onClose,
}: {
  stageLabel: string;
  stepTitle: string;
  onClose: () => void;
}) {
  return (
    <section
      aria-label="Preciso de ajuda"
      className="flex gap-4 rounded-2xl border border-red-500/40 bg-red-500/5 p-5 sm:p-6"
    >
      <Icon name="help" className="mt-0.5 h-6 w-6 text-red-300" />
      <div className="min-w-0 flex-1 space-y-2">
        <h3 className="font-semibold text-white">Preciso de ajuda</h3>
        <p className="text-base font-medium text-red-100">
          Interrompa esta etapa e consulte o responsável pelo almoxarifado.
        </p>
        <p className="text-sm text-zinc-400">
          Não execute ações que não estejam descritas neste procedimento. Informe ao responsável a etapa em que
          você está:{" "}
          <span className="text-zinc-200">
            {stageLabel} — {stepTitle}
          </span>
          .
        </p>
      </div>
      <Button variant="ghost" onClick={onClose} aria-label="Fechar ajuda" className="h-10 w-10 shrink-0 px-0">
        <Icon name="x" />
      </Button>
    </section>
  );
}
