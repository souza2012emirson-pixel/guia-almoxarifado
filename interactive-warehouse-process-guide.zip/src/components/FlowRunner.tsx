import { useEffect, useRef, useState } from "react";
import type { ProcessDefinition } from "../types";
import { useFlow } from "../engine/useFlow";
import { AlertsPanel, HelpPanel, ProgressPanel, TrailBar } from "./FlowWidgets";
import { Icon } from "./icons";
import { StepView } from "./StepViews";
import { Button, NoticeBox } from "./ui";

interface FlowRunnerProps {
  process: ProcessDefinition;
  onExit: () => void;
}

/**
 * Executa um processo: mostra uma etapa por vez, mantém o histórico para
 * "Voltar", a trilha clicável, o indicador de progresso e a ajuda.
 */
export default function FlowRunner({ process, onExit }: FlowRunnerProps) {
  if (!process.flow) {
    return (
      <div className="rounded-2xl border border-red-500/40 bg-red-500/10 p-6 text-red-100">
        Este processo ainda não possui fluxo configurado.
      </div>
    );
  }
  // A chave reinicia o estado interno ao trocar de processo.
  return <FlowSession key={process.id} process={process} onExit={onExit} />;
}

function FlowSession({ process, onExit }: FlowRunnerProps) {
  const flow = process.flow!;
  const { state, step, trail, stageIndex, canBack, actions } = useFlow(flow);
  const [helpOpen, setHelpOpen] = useState(false);
  const [confirmRestart, setConfirmRestart] = useState(false);
  const headingRef = useRef<HTMLHeadingElement>(null);

  // A cada mudança de passo: fecha a ajuda, cancela confirmação pendente e leva o foco ao título.
  useEffect(() => {
    setHelpOpen(false);
    setConfirmRestart(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
    headingRef.current?.focus({ preventScroll: true });
  }, [state.current]);

  const stage = flow.stages[stageIndex];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-3">
        <Button variant="ghost" onClick={onExit}>
          <Icon name="arrow-left" className="h-4 w-4" />
          Todos os processos
        </Button>
        <p className="ml-auto text-xs text-zinc-500">
          Processo: <span className="text-zinc-300">{process.title}</span>
        </p>
      </div>

      <ProgressPanel stages={flow.stages} currentIndex={stageIndex} stepsCount={state.history.length} />

      <TrailBar trail={trail} currentIndex={state.history.length} onJump={actions.jump} />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_300px]">
        <section className="min-w-0 space-y-6">
          <article className="overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900/80 shadow-xl shadow-black/30">
            <header className="border-b border-zinc-800 px-5 py-5 sm:px-7">
              {stage && (
                <p className="mb-2 inline-flex items-center rounded-full border border-violet-500/40 bg-violet-500/10 px-3 py-0.5 text-xs font-semibold text-violet-200">
                  Etapa {stage.id} · {stage.label}
                </p>
              )}
              <h2
                ref={headingRef}
                tabIndex={-1}
                className="text-2xl font-bold leading-tight text-white outline-none sm:text-3xl"
              >
                {step.title}
              </h2>
            </header>

            <div className="space-y-6 px-5 py-6 sm:px-7 sm:py-8">
              {step.notes && step.notes.length > 0 && (
                <div className="space-y-3">
                  {step.notes.map((note, index) => (
                    <NoticeBox key={index} note={note} />
                  ))}
                </div>
              )}

              <StepView
                key={step.id}
                step={step}
                answers={state.answers}
                actions={actions}
                trail={trail}
                onExit={onExit}
              />
            </div>

            <footer className="flex flex-wrap items-center gap-2 border-t border-zinc-800 bg-zinc-950/40 px-5 py-4 sm:px-7">
              <Button onClick={actions.back} disabled={!canBack}>
                <Icon name="arrow-left" className="h-4 w-4" />
                Voltar
              </Button>
              <Button variant="ghost" onClick={() => setHelpOpen((open) => !open)} aria-expanded={helpOpen}>
                <Icon name="help" className="h-4 w-4" />
                Preciso de ajuda
              </Button>

              <div className="ml-auto">
                {confirmRestart ? (
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm text-zinc-400">Apagar o caminho atual?</span>
                    <Button variant="danger" onClick={actions.restart}>
                      Sim, reiniciar
                    </Button>
                    <Button onClick={() => setConfirmRestart(false)}>Cancelar</Button>
                  </div>
                ) : (
                  <Button variant="ghost" onClick={() => setConfirmRestart(true)}>
                    <Icon name="refresh" className="h-4 w-4" />
                    Reiniciar processo
                  </Button>
                )}
              </div>
            </footer>
          </article>

          {helpOpen && (
            <HelpPanel
              stageLabel={stage ? `Etapa ${stage.id}` : ""}
              stepTitle={step.title}
              onClose={() => setHelpOpen(false)}
            />
          )}

          <p className="text-xs leading-relaxed text-zinc-600">{flow.source}</p>
        </section>

        <AlertsPanel />
      </div>
    </div>
  );
}
