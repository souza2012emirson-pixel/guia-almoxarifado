import { useMemo, useState } from "react";
import { processes } from "../data/processes";
import type { ProcessDefinition } from "../types";
import { cn } from "../utils/cn";
import { Icon } from "./icons";
import { Button } from "./ui";

const normalize = (text: string) =>
  text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();

/** Busca: todos os termos digitados devem aparecer em algum campo do processo. */
function matchesQuery(process: ProcessDefinition, query: string): boolean {
  const terms = normalize(query).split(/\s+/).filter(Boolean);
  if (terms.length === 0) return true;
  const haystack = normalize([process.title, process.category, process.description, ...process.keywords].join(" "));
  return terms.every((term) => haystack.includes(term));
}

const howToUse = [
  { title: "Uma etapa por vez", text: "Responda à pergunta ou confirme a instrução exibida." },
  { title: "Revise sem perder dados", text: "Use “Voltar” ou clique em uma etapa do caminho percorrido." },
  { title: "Em dúvida, peça ajuda", text: "“Preciso de ajuda” orienta a interromper e consultar o responsável." },
  { title: "Sempre confira no TOTVS", text: "O guia não substitui a conferência no sistema nem as regras internas." },
];

export default function HomeView({ onOpen }: { onOpen: (id: string) => void }) {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => processes.filter((p) => matchesQuery(p, query)), [query]);
  const available = filtered.filter((p) => p.status === "disponivel");
  const upcoming = filtered.filter((p) => p.status === "em-desenvolvimento");

  return (
    <div className="space-y-10">
      {/* Apresentação */}
      <section className="space-y-4">
        <p className="text-sm font-medium uppercase tracking-widest text-violet-300">Assistente operacional</p>
        <h2 className="max-w-3xl text-3xl font-bold leading-tight text-white sm:text-4xl">
          Escolha o processo e siga as instruções, uma etapa por vez.
        </h2>
        <p className="max-w-3xl text-base text-zinc-400">
          O guia faz perguntas, indica o próximo passo e orienta o que fazer quando algo não confere.
        </p>
      </section>

      {/* Como usar */}
      <section aria-label="Como usar o guia" className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {howToUse.map((item) => (
          <div key={item.title} className="rounded-xl border border-zinc-800 bg-zinc-900/50 p-4">
            <p className="text-sm font-semibold text-zinc-100">{item.title}</p>
            <p className="mt-1 text-sm text-zinc-500">{item.text}</p>
          </div>
        ))}
      </section>

      {/* Busca */}
      <section aria-label="Buscar processos" className="space-y-3">
        <label htmlFor="busca-processo" className="text-sm font-medium text-zinc-300">
          Buscar processo ou palavra-chave
        </label>
        <div className="relative">
          <Icon name="search" className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-zinc-500" />
          <input
            id="busca-processo"
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Ex.: endereçar, box, F4, armazém, etiqueta"
            className="w-full rounded-xl border border-zinc-700 bg-zinc-900 py-3.5 pl-12 pr-4 text-base text-white placeholder:text-zinc-500 focus:border-violet-500 focus:outline-none focus:ring-2 focus:ring-violet-500/30"
          />
        </div>
        <p className="text-sm text-zinc-500" aria-live="polite">
          {filtered.length === 0
            ? "Nenhum processo encontrado. Tente outra palavra-chave ou consulte o responsável pelo almoxarifado."
            : `${filtered.length} ${filtered.length === 1 ? "processo encontrado" : "processos encontrados"}`}
        </p>
      </section>

      {/* Disponíveis */}
      {available.length > 0 && (
        <section aria-labelledby="titulo-disponiveis" className="space-y-4">
          <h3 id="titulo-disponiveis" className="text-lg font-semibold text-white">
            Processos disponíveis
          </h3>
          <div className="grid gap-4 md:grid-cols-2">
            {available.map((process) => (
              <article
                key={process.id}
                className="flex flex-col rounded-2xl border border-zinc-800 bg-zinc-900/70 p-5 transition hover:border-violet-500/60 hover:bg-zinc-900"
              >
                <div className="flex items-center justify-between gap-3">
                  <span className="text-xs font-semibold uppercase tracking-wide text-violet-300">
                    {process.category}
                  </span>
                  <span className="rounded-full bg-emerald-500/15 px-2.5 py-1 text-xs font-medium text-emerald-300">
                    Disponível
                  </span>
                </div>
                <h4 className="mt-3 text-xl font-semibold text-white">{process.title}</h4>
                <p className="mt-2 flex-1 text-sm leading-relaxed text-zinc-400">{process.description}</p>
                <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
                  <span className="text-xs text-zinc-500">
                    Fluxo com {process.flow?.stages.length ?? 0} etapas
                  </span>
                  <Button variant="primary" onClick={() => onOpen(process.id)}>
                    Iniciar processo
                    <Icon name="arrow-right" className="h-4 w-4" />
                  </Button>
                </div>
              </article>
            ))}
          </div>
        </section>
      )}

      {/* Em desenvolvimento */}
      {upcoming.length > 0 && (
        <section aria-labelledby="titulo-desenvolvimento" className="space-y-4">
          <div>
            <h3 id="titulo-desenvolvimento" className="text-lg font-semibold text-white">
              Em desenvolvimento
            </h3>
            <p className="text-sm text-zinc-500">
              Categorias previstas. Ainda não possuem procedimento aprovado para execução.
            </p>
          </div>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {upcoming.map((process) => (
              <article
                key={process.id}
                aria-disabled="true"
                className={cn("flex flex-col rounded-xl border border-dashed border-zinc-700 bg-zinc-900/40 p-4")}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-medium uppercase tracking-wide text-zinc-500">{process.category}</span>
                  <span className="rounded-full bg-amber-500/10 px-2.5 py-1 text-[11px] font-medium text-amber-300">
                    Em desenvolvimento
                  </span>
                </div>
                <h4 className="mt-2 text-base font-semibold text-zinc-300">{process.title}</h4>
              </article>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
