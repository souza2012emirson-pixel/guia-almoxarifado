import type { ButtonHTMLAttributes } from "react";
import type { Note, NoteTone, Option } from "../types";
import { cn } from "../utils/cn";
import { Icon, type IconName } from "./icons";

/* ───────────── Botões ───────────── */

export type ButtonVariant = "primary" | "success" | "warning" | "danger" | "secondary" | "ghost";

const buttonVariants: Record<ButtonVariant, string> = {
  primary: "border-violet-500 bg-violet-600 text-white shadow-lg shadow-violet-900/30 hover:bg-violet-500",
  success: "border-emerald-500/60 bg-emerald-500/10 text-emerald-200 hover:bg-emerald-500/20",
  warning: "border-amber-500/60 bg-amber-500/10 text-amber-200 hover:bg-amber-500/20",
  danger: "border-red-500/60 bg-red-500/10 text-red-200 hover:bg-red-500/20",
  secondary: "border-zinc-700 bg-zinc-800 text-zinc-100 hover:bg-zinc-700",
  ghost: "border-transparent bg-transparent text-zinc-400 hover:bg-zinc-800 hover:text-zinc-100",
};

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: "md" | "lg";
}

export function Button({ variant = "secondary", size = "md", className, children, ...props }: ButtonProps) {
  return (
    <button
      type="button"
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-xl border font-medium transition",
        "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-400",
        "disabled:cursor-not-allowed disabled:opacity-40",
        size === "lg" ? "min-h-12 px-5 py-3 text-base" : "min-h-10 px-4 py-2 text-sm",
        buttonVariants[variant],
        className,
      )}
      {...props}
    >
      {children}
    </button>
  );
}

/* ───────────── Opções de resposta ───────────── */

const optionStyles: Record<NonNullable<Option["tone"]>, string> = {
  primary: "border-violet-500/60 bg-violet-600/15 text-violet-100 hover:bg-violet-600/30",
  success: "border-emerald-500/60 bg-emerald-500/10 text-emerald-100 hover:bg-emerald-500/20",
  warning: "border-amber-500/60 bg-amber-500/10 text-amber-100 hover:bg-amber-500/20",
  danger: "border-red-500/60 bg-red-500/10 text-red-100 hover:bg-red-500/20",
  secondary: "border-zinc-700 bg-zinc-800 text-zinc-100 hover:bg-zinc-700",
};

const optionDot: Record<NonNullable<Option["tone"]>, string> = {
  primary: "bg-violet-400",
  success: "bg-emerald-400",
  warning: "bg-amber-400",
  danger: "bg-red-400",
  secondary: "bg-zinc-500",
};

export function OptionButton({
  option,
  selected,
  onSelect,
}: {
  option: Option;
  selected: boolean;
  onSelect: () => void;
}) {
  const tone = option.tone ?? "secondary";
  return (
    <button
      type="button"
      onClick={onSelect}
      aria-pressed={selected}
      className={cn(
        "flex min-h-16 items-center justify-between gap-3 rounded-xl border px-5 py-4 text-left text-base font-semibold transition",
        "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-400",
        optionStyles[tone],
        selected && "ring-2 ring-white/50",
      )}
    >
      <span className="flex items-center gap-3">
        <span className={cn("h-3 w-3 shrink-0 rounded-full", optionDot[tone])} aria-hidden="true" />
        {option.label}
      </span>
      {selected && (
        <span className="shrink-0 rounded bg-zinc-950/70 px-2 py-0.5 text-[11px] font-medium text-zinc-300">
          Resposta anterior
        </span>
      )}
    </button>
  );
}

/* ───────────── Alertas ───────────── */

const toneStyles: Record<NoteTone, { box: string; icon: string; iconName: IconName; label: string }> = {
  info: {
    box: "border-violet-500/40 bg-violet-500/10",
    icon: "text-violet-300",
    iconName: "help",
    label: "Informação",
  },
  warning: {
    box: "border-amber-500/50 bg-amber-500/10",
    icon: "text-amber-300",
    iconName: "alert",
    label: "Atenção",
  },
  danger: {
    box: "border-red-500/60 bg-red-500/10",
    icon: "text-red-300",
    iconName: "octagon",
    label: "Bloqueio",
  },
  success: {
    box: "border-emerald-500/50 bg-emerald-500/10",
    icon: "text-emerald-300",
    iconName: "check",
    label: "Confirmado",
  },
  validate: {
    box: "border-dashed border-amber-400/70 bg-amber-400/5",
    icon: "text-amber-200",
    iconName: "alert",
    label: "A validar",
  },
};

const VALIDATE_DEFAULT = "Procedimento a validar com o responsável pelo almoxarifado.";

export function NoticeBox({ note, compact = false }: { note: Note; compact?: boolean }) {
  const style = toneStyles[note.tone];
  const text = note.tone === "validate" ? note.text ?? VALIDATE_DEFAULT : note.text;
  return (
    <div
      role={note.tone === "danger" || note.tone === "warning" ? "alert" : undefined}
      className={cn("flex gap-3 rounded-xl border p-4", style.box, compact && "p-3")}
    >
      <Icon name={style.iconName} className={cn("mt-0.5 h-5 w-5", style.icon)} />
      <div className="min-w-0 space-y-1">
        <p className={cn("text-xs font-semibold uppercase tracking-wide", style.icon)}>
          {note.title ?? style.label}
        </p>
        {text && <p className={cn("leading-relaxed text-zinc-200", compact ? "text-sm" : "text-sm sm:text-base")}>{text}</p>}
      </div>
    </div>
  );
}
