import type { ReactNode } from "react";
import type {
  ChecklistStep,
  EndStep,
  ExceptionStep,
  InstructionStep,
  MultiQuestionStep,
  QuestionStep,
  Step,
} from "../types";
import type { FlowActions, TrailItem } from "../engine/flowEngine";
import { cn } from "../utils/cn";
import { Icon } from "./icons";
import { Button, OptionButton } from "./ui";

/**
 * Renderizador dos tipos de passo. Cada `kind` tem uma view própria.
 * Para criar um novo tipo de passo: adicione-o em `types.ts`, uma view aqui
 * e um `case` em `StepView`.
 */

interface StepViewProps {
  step: Step;
  answers: Record<string, string>;
  actions: FlowActions;
  trail: TrailItem[];
  onExit: () => void;
}

export function StepView({ step, answers, actions, trail, onExit }: StepViewProps) {
  switch (step.kind) {
    case "instruction":
      return <InstructionView step={step} actions={actions} />;
    case "question":
      return <QuestionView step={step} answers={answers} actions={actions} />;
    case "multi-question":
      return <MultiQuestionView step={step} answers={answers} actions={actions} />;
    case "exception":
      return <ExceptionView step={step} answers={answers} actions={actions} />;
    case "checklist":
      return <ChecklistView step={step} answers={answers} actions={actions} />;
    case "end":
      return <EndView step={step} trail={trail} actions={actions} onExit={onExit} />;
  }
}

/* ───────────── Auxiliares ───────────── */

function Paragraphs({ items, className }: { items: string[]; className?: string }) {
  return (
    <div className={cn("space-y-3 text-base leading-relaxed text-zinc-300", className)}>
      {items.map((item) => (
        <p key={item}>{item}</p>
      ))}
    </div>
  );
}

function Block({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="space-y-2 rounded-xl border border-zinc-800 bg-zinc-950/50 p-4 sm:p-5">
      <h4 className="text-xs font-semibold uppercase tracking-wide text-zinc-500">{title}</h4>
      <div className="text-base leading-relaxed text-zinc-200">{children}</div>
    </section>
  );
}

function BulletList({ items }: { items: string[] }) {
  return (
    <ul className="list-disc space-y-2 pl-5 marker:text-violet-400">
      {items.map((item) => (
        <li key={item}>{item}</li>
      ))}
    </ul>
  );
}

function MenuPath({ items }: { items: string[] }) {
  return (
    <div className="rounded-xl border border-zinc-700 bg-zinc-950/60 p-4 sm:p-5">
      <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-zinc-500">
        Caminho no TOTVS Protheus
      </p>
      <ol className="flex flex-wrap items-center gap-2">
        {items.map((item, index) => {
          const isLast = index === items.length - 1;
          return (
            <li key={item} className="flex items-center gap-2">
              <span
                className={cn(
                  "rounded-lg border px-3 py-2 text-sm font-medium",
                  isLast ? "border-violet-500 bg-violet-600 text-white" : "border-zinc-700 bg-zinc-800 text-zinc-100",
                )}
              >
                {item}
              </span>
              {!isLast && <Icon name="chevron-right" className="h-4 w-4 text-zinc-500" />}
            </li>
          );
        })}
      </ol>
    </div>
  );
}

/* ───────────── Instrução ───────────── */

function InstructionView({ step, actions }: { step: InstructionStep; actions: FlowActions }) {
  return (
    <div className="space-y-6">
      {step.body.length > 1 ? (
        <ol className="space-y-3">
          {step.body.map((item, index) => (
            <li key={item} className="flex gap-4 text-base leading-relaxed text-zinc-200 sm:text-lg">
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-violet-600/20 text-sm font-semibold text-violet-200">
                {index + 1}
              </span>
              <span className="pt-0.5">{item}</span>
            </li>
          ))}
        </ol>
      ) : (
        <p className="text-lg leading-relaxed text-zinc-200">{step.body[0]}</p>
      )}

      {step.menuPath && <MenuPath items={step.menuPath} />}

      <div>
        <Button
          variant="primary"
          size="lg"
          onClick={() => actions.go(step.next, { key: step.id, value: "Concluído" })}
        >
          <Icon name="check" className="h-5 w-5" />
          {step.nextLabel ?? "Sim, concluído"}
        </Button>
      </div>
    </div>
  );
}

/* ───────────── Pergunta ───────────── */

function QuestionView({
  step,
  answers,
  actions,
}: {
  step: QuestionStep;
  answers: Record<string, string>;
  actions: FlowActions;
}) {
  const previous = answers[step.id];
  return (
    <div className="space-y-6">
      {step.body && <Paragraphs items={step.body} />}
      <h3 className="text-xl font-semibold leading-snug text-white sm:text-2xl">{step.question}</h3>
      <div className={cn("grid gap-3", step.options.length > 2 ? "sm:grid-cols-3" : "sm:grid-cols-2")}>
        {step.options.map((option) => (
          <OptionButton
            key={option.label}
            option={option}
            selected={previous === option.label}
            onSelect={() => actions.go(option.target, { key: step.id, value: option.label })}
          />
        ))}
      </div>
    </div>
  );
}

/* ───────────── Verificações obrigatórias (várias perguntas) ───────────── */

function MultiQuestionView({
  step,
  answers,
  actions,
}: {
  step: MultiQuestionStep;
  answers: Record<string, string>;
  actions: FlowActions;
}) {
  const total = step.questions.length;
  const confirmedCount = step.questions.filter((q) => answers[`${step.id}.${q.id}`] === "Sim").length;
  const allConfirmed = confirmedCount === total;

  return (
    <div className="space-y-6">
      {step.body && <Paragraphs items={step.body} />}

      <ul className="space-y-3">
        {step.questions.map((question) => {
          const key = `${step.id}.${question.id}`;
          const value = answers[key];
          return (
            <li key={question.id} className="rounded-xl border border-zinc-700 bg-zinc-950/50 p-4 sm:p-5">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0">
                  <p className="text-base font-semibold text-white sm:text-lg">{question.text}</p>
                  {question.hint && <p className="mt-1 text-sm text-zinc-400">{question.hint}</p>}
                </div>
                <div className="flex shrink-0 gap-2">
                  <Button
                    variant={value === "Sim" ? "success" : "secondary"}
                    aria-pressed={value === "Sim"}
                    onClick={() => actions.mark(key, "Sim")}
                    className="min-w-24"
                  >
                    {value === "Sim" && <Icon name="check" className="h-4 w-4" />}
                    Sim
                  </Button>
                  <Button
                    variant="danger"
                    aria-pressed={value === "Não"}
                    onClick={() => actions.go(question.onNo, { key, value: "Não" })}
                    className="min-w-24"
                  >
                    Não
                  </Button>
                </div>
              </div>
            </li>
          );
        })}
      </ul>

      <div className="flex flex-col gap-4 rounded-xl border border-zinc-700 bg-zinc-950/60 p-4 sm:flex-row sm:items-center sm:justify-between sm:p-5">
        <p className="text-sm text-zinc-400">
          {allConfirmed
            ? "Todas as verificações foram confirmadas. Você pode continuar."
            : `${confirmedCount} de ${total} confirmadas. O avanço só é liberado quando as três respostas forem “Sim”.`}
        </p>
        <Button
          variant="primary"
          size="lg"
          disabled={!allConfirmed}
          onClick={() => actions.go(step.next, { key: step.id, value: "Confirmado (3 de 3)" })}
        >
          {step.nextLabel ?? "Confirmar e continuar"}
        </Button>
      </div>
    </div>
  );
}

/* ───────────── Exceção / interrupção ───────────── */

function ExceptionView({
  step,
  answers,
  actions,
}: {
  step: ExceptionStep;
  answers: Record<string, string>;
  actions: FlowActions;
}) {
  const isStop = !step.options || step.options.length === 0;
  const previous = answers[step.id];

  return (
    <div className="space-y-5">
      <div
        className={cn(
          "flex items-start gap-3 rounded-xl border p-4",
          isStop ? "border-red-500/60 bg-red-500/10" : "border-amber-500/50 bg-amber-500/10",
        )}
      >
        <Icon
          name={isStop ? "octagon" : "alert"}
          className={cn("mt-0.5 h-6 w-6", isStop ? "text-red-300" : "text-amber-300")}
        />
        <div className="space-y-1">
          <p className="font-semibold text-white">
            {isStop ? "Interrupção: não prossiga automaticamente" : "Exceção identificada"}
          </p>
          {isStop && (
            <p className="text-sm font-medium text-red-100">
              Interrompa esta etapa e consulte o responsável pelo almoxarifado.
            </p>
          )}
        </div>
      </div>

      <Block title="O que foi identificado">
        <p>{step.identified}</p>
      </Block>

      <Block title="O que verificar">
        <BulletList items={step.verify} />
      </Block>

      <Block title="Ação permitida pelo procedimento">
        <BulletList items={step.allowed} />
      </Block>

      <Block title="Quando interromper e solicitar ajuda">
        <p>{step.stopWhen}</p>
      </Block>

      {!isStop && step.options && (
        <div className="grid gap-3 pt-2 sm:grid-cols-2">
          {step.options.map((option) => (
            <OptionButton
              key={option.label}
              option={option}
              selected={previous === option.label}
              onSelect={() => actions.go(option.target, { key: step.id, value: option.label })}
            />
          ))}
        </div>
      )}
    </div>
  );
}

/* ───────────── Checklist final ───────────── */

function ChecklistView({
  step,
  answers,
  actions,
}: {
  step: ChecklistStep;
  answers: Record<string, string>;
  actions: FlowActions;
}) {
  const keys = step.items.map((_, index) => `${step.id}.${index}`);
  const checkedCount = keys.filter((key) => answers[key] === "Sim").length;
  const allChecked = checkedCount === keys.length;

  return (
    <div className="space-y-6">
      {step.body && <Paragraphs items={step.body} />}

      <ul className="space-y-2">
        {step.items.map((item, index) => {
          const key = keys[index];
          const checked = answers[key] === "Sim";
          return (
            <li key={key}>
              <button
                type="button"
                role="checkbox"
                aria-checked={checked}
                onClick={() => actions.mark(key, checked ? "Não" : "Sim")}
                className={cn(
                  "flex w-full items-center gap-4 rounded-xl border p-4 text-left text-base transition",
                  "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-400",
                  checked
                    ? "border-emerald-500/60 bg-emerald-500/10 text-emerald-50"
                    : "border-zinc-700 bg-zinc-950/50 text-zinc-200 hover:border-zinc-500",
                )}
              >
                <span
                  className={cn(
                    "flex h-6 w-6 shrink-0 items-center justify-center rounded-md border-2",
                    checked ? "border-emerald-400 bg-emerald-500 text-zinc-950" : "border-zinc-500",
                  )}
                  aria-hidden="true"
                >
                  {checked && <Icon name="check" className="h-4 w-4" />}
                </span>
                <span>{item}</span>
              </button>
            </li>
          );
        })}
      </ul>

      {allChecked ? (
        <div className="rounded-xl border border-emerald-500/50 bg-emerald-500/10 p-4 text-emerald-100">
          <p className="font-semibold">Todos os itens obrigatórios foram confirmados.</p>
          <p className="text-sm text-emerald-200/80">Finalize o processo para ver o encerramento.</p>
        </div>
      ) : (
        <p className="text-sm text-zinc-400">
          {checkedCount} de {keys.length} itens confirmados. Marque todos para finalizar.
        </p>
      )}

      <div>
        <Button
          variant="primary"
          size="lg"
          disabled={!allChecked}
          onClick={() => actions.go(step.next, { key: step.id, value: "Concluído" })}
        >
          {step.nextLabel ?? "Finalizar processo"}
        </Button>
      </div>
    </div>
  );
}

/* ───────────── Encerramento ───────────── */

function EndView({
  step,
  trail,
  actions,
  onExit,
}: {
  step: EndStep;
  trail: TrailItem[];
  actions: FlowActions;
  onExit: () => void;
}) {
  const summary = trail.filter((item) => item.id !== step.id);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 rounded-xl border border-emerald-500/60 bg-emerald-500/10 p-5">
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-emerald-500 text-zinc-950">
          <Icon name="check" className="h-6 w-6" />
        </span>
        <p className="text-xl font-bold text-emerald-100 sm:text-2xl">Conferência do processo concluída</p>
      </div>

      <Paragraphs items={step.body} />

      <section className="space-y-3">
        <h4 className="text-xs font-semibold uppercase tracking-wide text-zinc-500">Resumo do percurso</h4>
        <ol className="divide-y divide-zinc-800 overflow-hidden rounded-xl border border-zinc-800 bg-zinc-950/50">
          {summary.map((item, index) => (
            <li key={`${item.id}-${index}`} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 text-sm">
              <span className="flex items-center gap-3 text-zinc-200">
                <span className="w-6 text-zinc-500">{index + 1}.</span>
                {item.title}
              </span>
              {item.answer && <span className="rounded bg-zinc-800 px-2 py-0.5 text-xs text-zinc-300">{item.answer}</span>}
            </li>
          ))}
        </ol>
      </section>

      <div className="flex flex-wrap gap-3 pt-2">
        <Button variant="primary" size="lg" onClick={actions.restart}>
          <Icon name="refresh" className="h-5 w-5" />
          Iniciar novo processo
        </Button>
        <Button size="lg" onClick={onExit}>
          Voltar aos processos
        </Button>
      </div>
    </div>
  );
}
