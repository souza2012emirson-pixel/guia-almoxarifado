import { Icon } from "./icons";

export function Header({ onHome }: { onHome: () => void }) {
  return (
    <header className="sticky top-0 z-30 border-b border-zinc-800 bg-zinc-950/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center gap-4 px-4 py-3 sm:px-6">
        <button
          type="button"
          onClick={onHome}
          aria-label="Ir para a página inicial de processos"
          className="flex min-w-0 items-center gap-3 rounded-xl text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-400"
        >
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-violet-600 shadow-lg shadow-violet-900/40">
            <Icon name="book" className="h-6 w-6 text-white" />
          </span>
          <span className="min-w-0">
            <span className="block truncate text-base font-semibold text-white sm:text-lg">
              Guia de Processos do Almoxarifado
            </span>
            <span className="block truncate text-xs text-zinc-400">
              TOTVS Protheus | Procedimentos Operacionais
            </span>
          </span>
        </button>
        <div className="ml-auto hidden text-right sm:block">
          <p className="text-sm font-medium text-zinc-200">Fiasul</p>
          <p className="text-xs text-zinc-500">Indústria de Fios de Toledo · Uso interno</p>
        </div>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-zinc-800 bg-zinc-950">
      <div className="mx-auto max-w-6xl space-y-1 px-4 py-6 text-xs leading-relaxed text-zinc-500 sm:px-6">
        <p>
          <span className="font-semibold text-zinc-300">Guia de apoio operacional.</span> Não substitui a
          conferência no TOTVS Protheus nem as regras internas autorizadas.
        </p>
        <p>
          Este guia não está integrado ao TOTVS, não realiza operações no sistema e não confirma que
          qualquer transação foi salva.
        </p>
      </div>
    </footer>
  );
}
