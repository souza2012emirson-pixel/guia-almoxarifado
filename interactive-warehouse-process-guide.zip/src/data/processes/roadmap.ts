import type { ProcessDefinition } from "../../types";

/**
 * Categorias previstas para expansão. Ainda NÃO possuem procedimento aprovado,
 * por isso aparecem como "Em desenvolvimento" e não são executáveis.
 *
 * Para liberar uma delas: crie o fluxo em um arquivo novo (ex.: recebimento.ts),
 * adicione-o em `index.ts` e troque `status` para "disponivel".
 */
function planned(
  id: string,
  title: string,
  category: string,
  keywords: string[],
): ProcessDefinition {
  return {
    id,
    title,
    category,
    description: "Processo previsto. Conteúdo a ser fornecido pelo responsável pelo almoxarifado.",
    keywords,
    status: "em-desenvolvimento",
  };
}

export const roadmapProcesses: ProcessDefinition[] = [
  planned("recebimento-mercadorias", "Recebimento de mercadorias", "Recebimento", [
    "recebimento",
    "entrada",
    "mercadoria",
    "nota fiscal",
  ]),
  planned("conferencia-nota", "Conferência de nota, código e quantidade", "Recebimento", [
    "nota fiscal",
    "conferência",
    "código",
    "quantidade",
  ]),
  planned("contagem-fisica", "Contagem física de materiais", "Estoque", [
    "contagem",
    "inventário",
    "estoque",
    "quantidade",
  ]),
  planned("organizacao-guarda", "Organização e guarda de peças", "Estoque", [
    "organização",
    "guarda",
    "peças",
    "prateleira",
  ]),
  planned("consulta-saldo", "Consulta de saldo no TOTVS", "TOTVS", [
    "saldo",
    "consulta",
    "estoque",
    "TOTVS",
  ]),
  planned("transferencia-armazens", "Transferência entre armazéns", "Movimentações", [
    "transferência",
    "armazém",
    "armazem",
    "movimentação",
  ]),
  planned("cadastro-enderecos", "Cadastro de endereços", "Cadastros", [
    "endereço",
    "box",
    "cadastro",
    "lupa",
  ]),
  planned("divergencias-estoque", "Divergências de estoque", "Divergências", [
    "divergência",
    "diferença",
    "saldo",
    "ajuste",
  ]),
  planned("entrega-retirada", "Entrega e retirada de materiais", "Movimentações", [
    "entrega",
    "retirada",
    "requisição",
    "saída",
  ]),
  planned("materiais-sem-requisicao", "Controle de materiais sem requisição", "Controle", [
    "sem requisição",
    "controle",
    "saída",
  ]),
  planned("problemas-sistema", "Tratamento de problemas de sistema", "Suporte", [
    "sistema",
    "erro",
    "TOTVS",
    "suporte",
    "protheus",
  ]),
];
