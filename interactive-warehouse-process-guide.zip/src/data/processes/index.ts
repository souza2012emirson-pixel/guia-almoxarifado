import type { ProcessDefinition } from "../../types";
import { enderecamentoGuarda } from "./enderecamento-guarda";
import { roadmapProcesses } from "./roadmap";

/**
 * REGISTRO DE PROCESSOS.
 *
 * Para incluir um novo processo executável:
 *  1. Crie o arquivo em `src/data/processes/` exportando um `ProcessDefinition` com `flow`.
 *  2. Importe-o aqui e adicione-o à lista abaixo.
 *
 * A ordem da lista define a ordem dos cartões na página inicial.
 */
export const processes: ProcessDefinition[] = [enderecamentoGuarda, ...roadmapProcesses];
