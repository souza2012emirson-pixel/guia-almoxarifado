import type { ProcessDefinition } from "../../types";

/**
 * PROCESSO: Endereçar e guardar material (TOTVS Protheus).
 *
 * Como editar:
 *  - Textos: altere `title`, `body`, `identified`, `verify`, `allowed`, `stopWhen`, `question`.
 *  - Ramificações: altere `target` (opções), `onNo` (verificações) e `next` (avanço).
 *    O valor deve ser o `id` de outro passo deste arquivo.
 *  - Alertas: `notes`. Use `tone: "validate"` para o que não consta do procedimento.
 *  - Novo passo: crie um objeto com `id` único, `stage` existente e `kind` válido
 *    (instruction | question | multi-question | exception | checklist | end),
 *    e ligue-o a partir de um passo existente.
 *
 * Fonte: procedimento "PASSO A PASSO PARA GUARDAR PEÇA NO TOTVS".
 * O conteúdo deve ser conferido com o PDF original antes da publicação
 * (itens marcados como "a validar" não constam do procedimento).
 */
export const enderecamentoGuarda: ProcessDefinition = {
  id: "enderecar-guardar",
  title: "Endereçar e guardar material",
  category: "Estoque e endereçamento",
  description:
    "Localize o produto no TOTVS Protheus, confira indicador, armazém e quantidade, valide ou cadastre o box e registre a distribuição.",
  keywords: [
    "endereçar",
    "endereçamento",
    "guardar",
    "guarda",
    "peça",
    "box",
    "boxes",
    "endereço",
    "F4",
    "lupa",
    "cadastro de endereço",
    "armazém",
    "armazem 04",
    "armazém 05",
    "qtd distribu",
    "distribuir",
    "etiqueta",
    "indicador",
    "TOTVS",
    "Protheus",
  ],
  status: "disponivel",
  flow: {
    id: "enderecar-guardar",
    title: "Endereçar e guardar material",
    source:
      "Base: “PASSO A PASSO PARA GUARDAR PEÇA NO TOTVS”. Itens marcados como “a validar” não constam do procedimento e devem ser confirmados com o responsável pelo almoxarifado.",
    start: "intro",
    stages: [
      { id: "A", label: "Acessar" },
      { id: "B", label: "Localizar produto" },
      { id: "C", label: "Situação do item" },
      { id: "D", label: "Armazém" },
      { id: "E", label: "Quantidade física" },
      { id: "F", label: "Endereço (F4)" },
      { id: "G", label: "Cadastro de endereço" },
      { id: "H", label: "Quantidade a distribuir" },
      { id: "I", label: "Guarda e conclusão" },
    ],
    steps: [
      // ───────────── INÍCIO ─────────────
      {
        id: "intro",
        kind: "instruction",
        stage: "A",
        title: "Antes de começar",
        body: [
          "Este guia acompanha, passo a passo, o endereçamento e a guarda de materiais no TOTVS Protheus.",
          "Tenha em mãos a etiqueta de recebimento que acompanha o material. O código do produto está nela.",
          "O guia não substitui a conferência no TOTVS nem as regras internas autorizadas. Ele não está integrado ao sistema e não confirma que nenhuma operação foi salva.",
        ],
        next: "a1-menu",
        nextLabel: "Entendi, começar",
      },

      // ───────────── ETAPA A: ACESSAR ─────────────
      {
        id: "a1-menu",
        kind: "instruction",
        stage: "A",
        title: "Acessar o endereçamento",
        body: ["Navegue no TOTVS Protheus pelo caminho abaixo, na ordem indicada."],
        menuPath: [
          "Atualizações",
          "Movimentações",
          "Internas (2)",
          "Endereçamento (2)",
          "Endereçar",
        ],
        notes: [
          {
            tone: "info",
            title: "Caminho do menu",
            text: "Siga exatamente os nomes e números indicados, como aparecem no documento.",
          },
        ],
        next: "a2-confirmar",
      },
      {
        id: "a2-confirmar",
        kind: "instruction",
        stage: "A",
        title: "Confirmar a tela de endereçamento",
        body: ["Clique em “Confirmar”, conforme o procedimento documentado."],
        notes: [
          {
            tone: "warning",
            title: "Menu indisponível",
            text: "Se o caminho do menu não estiver disponível para o seu usuário, interrompa e consulte o responsável pelo almoxarifado. Não tente outro caminho.",
          },
        ],
        next: "b1-filtro",
      },

      // ───────────── ETAPA B: LOCALIZAR ─────────────
      {
        id: "b1-filtro",
        kind: "instruction",
        stage: "B",
        title: "Filtrar o produto pelo código",
        body: [
          "Clique nos três pontos (⋯) do filtro.",
          "Use a coluna “Produto”, e não a coluna “Chave”, para filtrar pelo código do produto.",
          "O código deve ser o que está na etiqueta de recebimento que acompanha o material.",
        ],
        notes: [
          {
            tone: "warning",
            title: "Coluna correta",
            text: "Não use a coluna “Chave” para filtrar pelo código do produto.",
          },
        ],
        next: "b2-localizou",
      },
      {
        id: "b2-localizou",
        kind: "question",
        stage: "B",
        title: "Produto localizado?",
        question: "Você conseguiu localizar o produto pelo código?",
        options: [
          { label: "Sim, localizei", target: "c1-indicador", tone: "primary" },
          { label: "Não", target: "b3-produto-nao-localizado", tone: "danger" },
        ],
      },
      {
        id: "b3-produto-nao-localizado",
        kind: "exception",
        stage: "B",
        title: "Produto não localizado",
        identified: "O produto não aparece na lista filtrada pelo código da etiqueta.",
        verify: [
          "O código digitado é exatamente o código da etiqueta de recebimento.",
          "O filtro foi feito pela coluna “Produto” (e não pela coluna “Chave”).",
          "Não restou outro critério de busca preenchido no filtro.",
        ],
        allowed: [
          "Corrigir o código digitado e revisar o filtro, conforme as etapas anteriores.",
        ],
        stopWhen:
          "Se o produto continuar sem aparecer depois da revisão, interrompa o fluxo e encaminhe o caso ao responsável pelo almoxarifado para análise.",
        options: [
          { label: "Revisei e localizei", target: "c1-indicador", tone: "primary" },
          { label: "Não encontrei", target: "x-parada-produto", tone: "danger" },
        ],
      },
      {
        id: "x-parada-produto",
        kind: "exception",
        stage: "B",
        title: "Produto não encontrado: interrupção",
        identified: "O produto não foi localizado, mesmo após revisar o código e o filtro.",
        verify: ["Código da etiqueta e filtro (coluna “Produto”) já foram revisados."],
        allowed: [
          "Nenhuma outra ação está descrita no procedimento. Não altere registros para contornar a situação.",
        ],
        stopWhen:
          "Agora. Encaminhe o caso ao responsável pelo almoxarifado para análise.",
      },

      // ───────────── ETAPA C: SITUAÇÃO DO ITEM ─────────────
      {
        id: "c1-indicador",
        kind: "question",
        stage: "C",
        title: "Indicador ao lado do item",
        body: ["Observe a cor do indicador ao lado do produto na lista."],
        question: "Qual indicador aparece ao lado do item?",
        options: [
          { label: "Verde", target: "c2-verde", tone: "success" },
          { label: "Vermelho", target: "x-vermelho", tone: "danger" },
          {
            label: "Outra cor ou nenhum indicador",
            target: "x-indicador-indefinido",
            tone: "warning",
          },
        ],
      },
      {
        id: "c2-verde",
        kind: "instruction",
        stage: "C",
        title: "Indicador verde: prosseguir",
        body: [
          "O procedimento indica que este item precisa ser endereçado e guardado.",
          "Siga para as verificações de armazém e de quantidade.",
        ],
        next: "d1-armazem",
        nextLabel: "Continuar",
      },
      {
        id: "x-vermelho",
        kind: "exception",
        stage: "C",
        title: "Indicador vermelho",
        identified:
          "O indicador ao lado do produto está vermelho. O procedimento indica que a entrada do item não foi registrada ou que o item já foi endereçado.",
        verify: [
          "Se a entrada do item foi registrada no sistema.",
          "Se o item já foi endereçado anteriormente.",
        ],
        allowed: [
          "Verificar a entrada e a situação do endereçamento. Não prossiga automaticamente.",
        ],
        stopWhen:
          "Se a situação não ficar esclarecida, interrompa e consulte o responsável pelo almoxarifado.",
        options: [
          { label: "Esclarecido: indicador agora verde", target: "c2-verde", tone: "success" },
          { label: "Continua vermelho / não esclareci", target: "x-parada-vermelho", tone: "danger" },
        ],
      },
      {
        id: "x-parada-vermelho",
        kind: "exception",
        stage: "C",
        title: "Situação não esclarecida: interrupção",
        identified: "O item continua com indicador vermelho e a situação não foi esclarecida.",
        verify: ["Entrada do item e situação do endereçamento foram verificadas."],
        allowed: [
          "Não prossiga com endereçamento ou guarda enquanto a situação não estiver esclarecida.",
        ],
        stopWhen:
          "Agora. Interrompa esta etapa e consulte o responsável pelo almoxarifado.",
      },
      {
        id: "x-indicador-indefinido",
        kind: "exception",
        stage: "C",
        title: "Indicador não previsto no procedimento",
        identified: "O indicador ao lado do item não é verde nem vermelho, ou não há indicador.",
        verify: ["Se o item está na linha correta do produto filtrado."],
        allowed: ["O procedimento não descreve este caso."],
        notes: [
          {
            tone: "validate",
            text: "Tratamento para indicador diferente de verde e vermelho: Procedimento a validar com o responsável pelo almoxarifado.",
          },
        ],
        stopWhen: "Interrompa esta etapa e consulte o responsável pelo almoxarifado.",
      },

      // ───────────── ETAPA D: ARMAZÉM ─────────────
      {
        id: "d1-armazem",
        kind: "question",
        stage: "D",
        title: "Armazém do produto",
        body: [
          "Os materiais devem estar no armazém 04 (estoque) ou no armazém 05 (barracão), conforme o procedimento.",
        ],
        question: "O produto está no armazém correto?",
        options: [
          { label: "Sim, está correto", target: "e1-enderecar", tone: "primary" },
          { label: "Não", target: "x-armazem-errado", tone: "danger" },
        ],
      },
      {
        id: "x-armazem-errado",
        kind: "exception",
        stage: "D",
        title: "Produto em armazém diferente do esperado",
        identified: "O produto está em um armazém diferente do esperado para o endereçamento.",
        verify: [
          "Em qual armazém o produto aparece no sistema.",
          "Se o armazém 04 ou o 05 é o correto para este item.",
        ],
        allowed: [
          "Encaminhar o caso ao Alisson para realizar a transferência ao armazém correto, conforme o procedimento descrito no PDF.",
          "Não realize transferências por conta própria: a autorização não é presumida.",
        ],
        stopWhen:
          "Interrompa até que a transferência seja feita pelo responsável. Só volte ao endereçamento depois que o produto estiver no armazém correto.",
        options: [
          { label: "Transferência feita: produto no armazém correto", target: "d1-armazem", tone: "primary" },
          { label: "Aguardando o Alisson", target: "x-aguardando-transferencia", tone: "warning" },
        ],
      },
      {
        id: "x-aguardando-transferencia",
        kind: "exception",
        stage: "D",
        title: "Aguardando transferência: interrupção",
        identified: "O produto segue em armazém diferente do esperado, e a transferência ainda não foi concluída.",
        verify: ["O produto ainda está fora do armazém correto."],
        allowed: ["Aguardar a conclusão da transferência pelo responsável. Não endereçar o produto nesta situação."],
        stopWhen: "Retome o processo somente depois que a transferência for confirmada.",
      },

      // ───────────── ETAPA E: QUANTIDADE FÍSICA ─────────────
      {
        id: "e1-enderecar",
        kind: "instruction",
        stage: "E",
        title: "Clicar em “Endereçar” e verificar a quantidade",
        body: [
          "Clique em “Endereçar”.",
          "Verifique a quantidade apresentada no sistema.",
          "Conte a quantidade física com atenção e compare com a informação exibida.",
        ],
        notes: [
          {
            tone: "warning",
            title: "Confira antes de confirmar",
            text: "Confira a quantidade física antes de confirmar a distribuição. Não prossiga com divergências sem esclarecimento.",
          },
        ],
        next: "e2-quantidade",
      },
      {
        id: "e2-quantidade",
        kind: "question",
        stage: "E",
        title: "Quantidade física",
        question: "A quantidade física confere com a quantidade que precisa ser endereçada?",
        options: [
          { label: "Sim, confere", target: "f1-f4", tone: "primary" },
          { label: "Não", target: "x-divergencia-quantidade", tone: "danger" },
        ],
      },
      {
        id: "x-divergencia-quantidade",
        kind: "exception",
        stage: "E",
        title: "Divergência de quantidade",
        identified: "A quantidade física não confere com a quantidade que precisa ser endereçada.",
        verify: [
          "A contagem física foi refeita com atenção.",
          "A quantidade exibida no sistema corresponde ao mesmo produto e armazém.",
        ],
        allowed: [
          "Refazer a contagem física e comparar novamente.",
          "Não realize ajuste de saldo: não há procedimento aprovado para isso.",
        ],
        stopWhen:
          "Se a divergência permanecer, interrompa o fluxo e sinalize ao responsável pelo almoxarifado. Não prossiga com divergências sem esclarecimento.",
        options: [
          { label: "Recontei: confere", target: "e2-quantidade", tone: "primary" },
          { label: "Divergência permanece", target: "x-parada-divergencia", tone: "danger" },
        ],
      },
      {
        id: "x-parada-divergencia",
        kind: "exception",
        stage: "E",
        title: "Divergência não esclarecida: interrupção",
        identified: "A quantidade física continua divergente da quantidade do sistema.",
        verify: ["A contagem foi refeita e comparada com a informação exibida."],
        allowed: [
          "Este guia não orienta ajuste de saldo. Não prossiga com a distribuição.",
        ],
        stopWhen:
          "Agora. Interrompa e sinalize a divergência ao responsável pelo almoxarifado.",
      },

      // ───────────── ETAPA F: ENDEREÇO (F4) ─────────────
      {
        id: "f1-f4",
        kind: "instruction",
        stage: "F",
        title: "Verificar o endereço existente (F4)",
        body: [
          "Dê um duplo clique na coluna “Endereço”.",
          "Pressione F4.",
        ],
        next: "f2-box",
      },
      {
        id: "f2-box",
        kind: "question",
        stage: "F",
        title: "Box cadastrado?",
        body: ["Observe o resultado após o F4."],
        question: "O sistema apresentou um box cadastrado?",
        options: [
          { label: "Sim, apareceu um box", target: "f3-confirmar-box", tone: "primary" },
          { label: "Não, nenhum box", target: "g1-lupa", tone: "warning" },
        ],
      },
      {
        id: "f3-confirmar-box",
        kind: "question",
        stage: "F",
        title: "Confirmar a localização do box",
        body: [
          "Compare o endereço apresentado com a localização física real do produto.",
          "Se o box já estiver cadastrado e validado para esse local, não é necessário novo cadastro.",
        ],
        notes: [
          {
            tone: "danger",
            title: "Sem guarda automática",
            text: "Se houver dúvida sobre a localização, não faça a guarda automática. Confirme o endereço correto antes de prosseguir.",
          },
        ],
        question: "O endereço apresentado corresponde à localização física correta do produto?",
        options: [
          { label: "Sim, está correto", target: "h1-quantidade-distribuir", tone: "success" },
          { label: "Não / tenho dúvida", target: "x-endereco-nao-confirmado", tone: "danger" },
        ],
      },
      {
        id: "x-endereco-nao-confirmado",
        kind: "exception",
        stage: "F",
        title: "Endereço cadastrado, localização não confirmada",
        identified:
          "Há um box apresentado, mas não há certeza de que ele corresponde à localização física correta do produto.",
        verify: [
          "A localização física real do produto.",
          "A descrição do endereço apresentado no sistema.",
        ],
        allowed: [
          "Confirmar qual é o endereço correto antes de prosseguir.",
          "Não autorizar a guarda automática enquanto o endereço não estiver confirmado.",
        ],
        stopWhen:
          "Se não for possível confirmar o endereço correto, interrompa e consulte o responsável pelo almoxarifado.",
        options: [
          { label: "Endereço confirmado", target: "f3-confirmar-box", tone: "primary" },
          { label: "Não foi possível confirmar", target: "x-parada-endereco", tone: "danger" },
        ],
      },
      {
        id: "x-parada-endereco",
        kind: "exception",
        stage: "F",
        title: "Endereço não confirmado: interrupção",
        identified: "O endereço correto do produto não pôde ser confirmado.",
        verify: ["A localização física foi conferida."],
        allowed: ["Não realize a guarda automática nem siga para a distribuição."],
        stopWhen: "Agora. Interrompa esta etapa e consulte o responsável pelo almoxarifado.",
      },

      // ───────────── ETAPA G: CADASTRO DE ENDEREÇO ─────────────
      {
        id: "g1-lupa",
        kind: "instruction",
        stage: "G",
        title: "Box não encontrado: cadastrar endereço",
        body: [
          "Clique na lupa da coluna “Endereço” para abrir a tela de cadastro.",
        ],
        notes: [
          {
            tone: "info",
            title: "Box não encontrado com F4",
            text: "O F4 não apresentou box cadastrado para este produto. Faça o cadastro do endereço nas próximas etapas.",
          },
        ],
        next: "g2-campos",
      },
      {
        id: "g2-campos",
        kind: "instruction",
        stage: "G",
        title: "Preencher os campos obrigatórios",
        body: [
          "Armazém: 04 ou 05, conforme a localização aplicável.",
          "Endereço: código do box, no padrão utilizado no almoxarifado.",
          "Descrição: descrição completa da localização física.",
          "Exemplos documentados: “FR/D/CX08” e “UGM/A/CX17”. São apenas exemplos: o endereço real deve ser confirmado.",
        ],
        notes: [
          {
            tone: "danger",
            title: "Não invente endereços",
            text: "Não crie códigos de box fictícios e não presuma que qualquer combinação de letras e números é válida.",
          },
          {
            tone: "validate",
            text: "Regras de formação do código do box e de quais padrões valem para cada armazém: Procedimento a validar com o responsável pelo almoxarifado.",
          },
        ],
        next: "g3-incluir",
      },
      {
        id: "g3-incluir",
        kind: "instruction",
        stage: "G",
        title: "Incluir e confirmar o cadastro",
        body: [
          "Clique em “Incluir”.",
          "Ao terminar o cadastro, clique em “Confirmar”.",
          "Siga as telas descritas no documento.",
        ],
        notes: [
          {
            tone: "validate",
            text: "Campos adicionais e mensagens das telas de cadastro: Procedimento a validar com o responsável pelo almoxarifado.",
          },
        ],
        next: "g4-aviso",
      },
      {
        id: "g4-aviso",
        kind: "question",
        stage: "G",
        title: "Aviso do sistema",
        question: "O sistema exibiu algum aviso ao informar o endereço?",
        options: [
          { label: "Não, sem aviso", target: "f1-f4", tone: "primary" },
          { label: "Sim, apareceu aviso", target: "x-aviso-sistema", tone: "danger" },
        ],
      },
      {
        id: "x-aviso-sistema",
        kind: "exception",
        stage: "G",
        title: "Aviso do sistema ao informar o endereço",
        identified: "Ao informar o endereço, o sistema apresentou um aviso.",
        verify: [
          "O texto exato do aviso.",
          "Se os campos Armazém, Endereço e Descrição foram preenchidos conforme as orientações.",
        ],
        allowed: [
          "Corrigir o preenchimento dos campos, se o erro estiver nos dados informados.",
          "Não tente contornar o aviso.",
        ],
        notes: [
          {
            tone: "validate",
            text: "Tratamento de avisos específicos do sistema: Procedimento a validar com o responsável pelo almoxarifado.",
          },
        ],
        stopWhen:
          "Se o aviso persistir ou não for compreendido, interrompa e consulte o responsável pelo almoxarifado.",
        options: [
          { label: "Aviso resolvido: validar box novamente", target: "f1-f4", tone: "primary" },
          { label: "Aviso persiste", target: "x-parada-aviso", tone: "danger" },
        ],
      },
      {
        id: "x-parada-aviso",
        kind: "exception",
        stage: "G",
        title: "Aviso não resolvido: interrupção",
        identified: "O aviso do sistema persiste e não foi compreendido.",
        verify: ["Texto do aviso e dados informados no cadastro."],
        allowed: ["Não avance com o cadastro nem com a distribuição."],
        stopWhen: "Agora. Interrompa esta etapa e consulte o responsável pelo almoxarifado.",
      },

      // ───────────── ETAPA H: QUANTIDADE A DISTRIBUIR ─────────────
      {
        id: "h1-quantidade-distribuir",
        kind: "instruction",
        stage: "H",
        title: "Informar a quantidade a distribuir",
        body: [
          "No campo “Qtd Distribu”, informe a quantidade física efetivamente conferida.",
          "Exemplo: se a quantidade conferida for 10 unidades, a quantidade a distribuir deve refletir essas 10 unidades, desde que seja a quantidade correta para a operação.",
        ],
        notes: [
          {
            tone: "warning",
            text: "Não informe quantidade diferente da quantidade física conferida.",
          },
        ],
        next: "h2-verificacoes",
      },
      {
        id: "h2-verificacoes",
        kind: "multi-question",
        stage: "H",
        title: "Verificações antes de concluir",
        body: [
          "Responda às três perguntas. Se qualquer resposta for “Não”, o guia direciona para a orientação correspondente e impede o avanço.",
        ],
        questions: [
          { id: "produto", text: "O produto é o correto?", onNo: "x-produto-incorreto" },
          {
            id: "quantidade",
            text: "A quantidade está correta?",
            onNo: "x-divergencia-quantidade",
          },
          {
            id: "endereco",
            text: "O endereço corresponde ao local físico correto?",
            onNo: "x-endereco-nao-confirmado",
          },
        ],
        next: "i1-guarda",
        nextLabel: "Confirmar as três verificações",
      },
      {
        id: "x-produto-incorreto",
        kind: "exception",
        stage: "H",
        title: "Produto incorreto",
        identified: "Na verificação final, o produto não está correto.",
        verify: [
          "O código do produto em relação à etiqueta de recebimento.",
          "A coluna de filtro utilizada (“Produto”).",
        ],
        allowed: ["Voltar à etapa de localização do produto e revisar o código e o filtro."],
        stopWhen:
          "Se não for possível localizar o produto correto, interrompa e encaminhe ao responsável pelo almoxarifado.",
        options: [
          { label: "Revisar localização do produto", target: "b1-filtro", tone: "primary" },
          { label: "Não foi possível localizar", target: "x-parada-produto", tone: "danger" },
        ],
      },

      // ───────────── ETAPA I: GUARDA E CONCLUSÃO ─────────────
      {
        id: "i1-guarda",
        kind: "instruction",
        stage: "I",
        title: "Guardar o material no local do endereço",
        body: [
          "Leve o material ao local físico correspondente ao endereço confirmado e guarde-o.",
          "Confirme, pela descrição cadastrada, que o local está correto.",
        ],
        notes: [
          {
            tone: "validate",
            text: "A forma de guarda física (embalagem, empilhamento, identificação do box) não consta no roteiro: Procedimento a validar com o responsável pelo almoxarifado.",
          },
        ],
        next: "i2-checklist",
        nextLabel: "Sim, guardado",
      },
      {
        id: "i2-checklist",
        kind: "checklist",
        stage: "I",
        title: "Checklist final",
        body: ["Marque cada item somente depois de conferi-lo."],
        notes: [
          {
            tone: "info",
            text: "Este guia não confirma que o registro foi salvo no TOTVS. Confira a operação no próprio sistema.",
          },
        ],
        items: [
          "Produto conferido.",
          "Armazém correto.",
          "Quantidade física conferida.",
          "Endereço validado ou cadastrado.",
          "Quantidade a distribuir conferida.",
          "Material guardado no local correspondente ao endereço.",
        ],
        next: "i3-fim",
        nextLabel: "Finalizar processo",
      },
      {
        id: "i3-fim",
        kind: "end",
        stage: "I",
        title: "Encerramento do processo",
        body: [
          "Todas as verificações obrigatórias foram confirmadas no guia.",
          "Lembrete: este guia não está integrado ao TOTVS e não confirma a gravação de nenhuma operação. Confirme o resultado no sistema e siga as regras internas autorizadas.",
        ],
      },
    ],
  },
};
