import { useState } from "react";
import FlowRunner from "./components/FlowRunner";
import HomeView from "./components/HomeView";
import { Footer, Header } from "./components/Header";
import { processes } from "./data/processes";

/**
 * Ponto de entrada da aplicação.
 * - Sem processo selecionado: página inicial com cartões e busca.
 * - Com processo selecionado: executor do fluxo interativo.
 * Os processos são definidos em `src/data/processes/`.
 */
export default function App() {
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const selected = processes.find(
    (process) => process.id === selectedId && process.status === "disponivel" && process.flow,
  );

  const openProcess = (id: string) => {
    setSelectedId(id);
    window.scrollTo({ top: 0 });
  };

  const goHome = () => {
    setSelectedId(null);
    window.scrollTo({ top: 0 });
  };

  return (
    <div className="flex min-h-screen flex-col bg-zinc-950 bg-[radial-gradient(ellipse_at_top,_rgba(124,58,237,0.14),_transparent_55%)] text-zinc-100 antialiased">
      <Header onHome={goHome} />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6 sm:px-6 lg:py-10">
        {selected ? (
          <FlowRunner process={selected} onExit={goHome} />
        ) : (
          <HomeView onOpen={openProcess} />
        )}
      </main>
      <Footer />
    </div>
  );
}
