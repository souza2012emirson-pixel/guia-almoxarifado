import { useEffect, useMemo, useReducer } from "react";
import type { FlowDefinition, Step } from "../types";
import {
  createInitialState,
  findStep,
  flowReducer,
  getStageIndex,
  validateFlow,
  type FlowActions,
  type TrailItem,
} from "./flowEngine";

/**
 * Hook que executa um fluxo: expõe o passo atual, a trilha percorrida,
 * o índice de etapa e as ações (ir, voltar, saltar para uma etapa anterior,
 * registrar resposta e reiniciar).
 */
export function useFlow(flow: FlowDefinition) {
  const [state, dispatch] = useReducer(flowReducer, flow.start, createInitialState);

  useEffect(() => {
    const errors = validateFlow(flow);
    if (errors.length > 0) {
      console.warn(`[Guia] Problemas no fluxo "${flow.id}":\n- ${errors.join("\n- ")}`);
    }
  }, [flow]);

  const step: Step =
    findStep(flow, state.current) ?? (findStep(flow, flow.start) as Step);

  const trail: TrailItem[] = [...state.history, state.current].map((id) => {
    const item = findStep(flow, id);
    return {
      id,
      title: item?.title ?? id,
      stage: item?.stage ?? "",
      answer: state.answers[id],
    };
  });

  const actions: FlowActions = useMemo(
    () => ({
      go: (to, record) => dispatch({ type: "go", to, record }),
      back: () => dispatch({ type: "back" }),
      jump: (index) => dispatch({ type: "jump", index }),
      mark: (key, value) => dispatch({ type: "mark", key, value }),
      restart: () => dispatch({ type: "restart", start: flow.start }),
    }),
    [flow.start],
  );

  return {
    state,
    step,
    trail,
    stageIndex: getStageIndex(flow, step.stage),
    canBack: state.history.length > 0,
    actions,
  };
}
