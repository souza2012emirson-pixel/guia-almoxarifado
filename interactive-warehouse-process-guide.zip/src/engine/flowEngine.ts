import type { FlowDefinition, Step } from "../types";

/**
 * Motor de navegação independente de interface.
 *
 * - `current`: id do passo atual.
 * - `history`: ids dos passos anteriores, em ordem (base do botão "Voltar" e da trilha).
 * - `answers`: respostas registradas por chave. Ficam preservadas ao voltar,
 *   para que o usuário veja o que já respondeu.
 */
export interface FlowState {
  current: string;
  history: string[];
  answers: Record<string, string>;
}

export interface TrailItem {
  id: string;
  title: string;
  stage: string;
  answer?: string;
}

export type FlowAction =
  | { type: "go"; to: string; record?: { key: string; value: string } }
  | { type: "back" }
  | { type: "jump"; index: number }
  | { type: "mark"; key: string; value: string }
  | { type: "restart"; start: string };

export interface FlowActions {
  go: (to: string, record?: { key: string; value: string }) => void;
  back: () => void;
  jump: (index: number) => void;
  mark: (key: string, value: string) => void;
  restart: () => void;
}

export function createInitialState(start: string): FlowState {
  return { current: start, history: [], answers: {} };
}

export function flowReducer(state: FlowState, action: FlowAction): FlowState {
  switch (action.type) {
    case "go": {
      const answers = action.record
        ? { ...state.answers, [action.record.key]: action.record.value }
        : state.answers;
      return {
        current: action.to,
        history: [...state.history, state.current],
        answers,
      };
    }
    case "back": {
      if (state.history.length === 0) return state;
      return {
        ...state,
        current: state.history[state.history.length - 1],
        history: state.history.slice(0, -1),
      };
    }
    case "jump": {
      const trail = [...state.history, state.current];
      if (action.index < 0 || action.index >= trail.length) return state;
      return {
        ...state,
        current: trail[action.index],
        history: trail.slice(0, action.index),
      };
    }
    case "mark":
      return { ...state, answers: { ...state.answers, [action.key]: action.value } };
    case "restart":
      return createInitialState(action.start);
    default:
      return state;
  }
}

export function findStep(flow: FlowDefinition, id: string): Step | undefined {
  return flow.steps.find((step) => step.id === id);
}

export function getStageIndex(flow: FlowDefinition, stageId: string): number {
  const index = flow.stages.findIndex((stage) => stage.id === stageId);
  return index < 0 ? 0 : index;
}

/** Lista os ids de destino de um passo (usado na validação). */
export function getTargets(step: Step): string[] {
  switch (step.kind) {
    case "instruction":
      return [step.next];
    case "question":
      return step.options.map((option) => option.target);
    case "multi-question":
      return [...step.questions.map((q) => q.onNo), step.next];
    case "exception":
      return step.options?.map((option) => option.target) ?? [];
    case "checklist":
      return [step.next];
    case "end":
      return [];
  }
}

/**
 * Valida um fluxo: ids duplicados, etapas inexistentes, destinos inexistentes
 * e passos inalcançáveis. Retorna a lista de problemas (vazia = fluxo válido).
 */
export function validateFlow(flow: FlowDefinition): string[] {
  const errors: string[] = [];
  const ids = new Set<string>();
  const stageIds = new Set(flow.stages.map((stage) => stage.id));

  for (const step of flow.steps) {
    if (ids.has(step.id)) errors.push(`ID duplicado: "${step.id}"`);
    ids.add(step.id);
    if (!stageIds.has(step.stage)) {
      errors.push(`Etapa inexistente em "${step.id}": "${step.stage}"`);
    }
  }

  if (!ids.has(flow.start)) errors.push(`Passo inicial inexistente: "${flow.start}"`);

  for (const step of flow.steps) {
    for (const target of getTargets(step)) {
      if (!ids.has(target)) {
        errors.push(`Destino inexistente em "${step.id}": "${target}"`);
      }
    }
  }

  // Busca em largura a partir do início para encontrar passos inalcançáveis.
  const reachable = new Set<string>();
  const queue = [flow.start];
  while (queue.length > 0) {
    const id = queue.shift() as string;
    if (reachable.has(id)) continue;
    reachable.add(id);
    const step = findStep(flow, id);
    if (step) queue.push(...getTargets(step));
  }
  for (const step of flow.steps) {
    if (!reachable.has(step.id)) errors.push(`Passo inalcançável: "${step.id}"`);
  }

  return errors;
}
